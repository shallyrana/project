package com.tanisha.restaurantinventory;

import jakarta.persistence.*;
import java.util.List;

@Entity
@Table(name = "supplier")
public class Supplier {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "name")
    private String name;

    @Column(name = "contact")
    private String contact;

    @Column(name = "vehicle_used")
    private String vehicleUsed;

    @Column(name = "items_delivering")
    private String itemsDelivering;

    @OneToOne(mappedBy = "supplier")
    private Warehouse warehouse;

    @OneToMany(mappedBy = "supplier", fetch = FetchType.EAGER)
    private List<Warehouse> warehouses;

    // Constructors
    public Supplier() {
    }

    public Supplier(String name, String contact, String vehicleUsed, String itemsDelivering) {
        this.name = name;
        this.contact = contact;
        this.vehicleUsed = vehicleUsed;
        this.itemsDelivering = itemsDelivering;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getContact() {
        return contact;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public String getVehicleUsed() {
        return vehicleUsed;
    }

    public void setVehicleUsed(String vehicleUsed) {
        this.vehicleUsed = vehicleUsed;
    }

    public String getItemsDelivering() {
        return itemsDelivering;
    }

    public void setItemsDelivering(String itemsDelivering) {
        this.itemsDelivering = itemsDelivering;
    }

    public Warehouse getWarehouse() {
        return warehouse;
    }

    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
    }

    public List<Warehouse> getWarehouses() {
        return warehouses;
    }

    public void setWarehouses(List<Warehouse> warehouses) {
        this.warehouses = warehouses;
    }
}
