package com.tanisha.restaurantinventory;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class TransportationDAO {

    private SessionFactory sessionFactory;

    public TransportationDAO() {
        this.sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    public void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }

    public void save(Transportation transportation) {
        Session session = sessionFactory.openSession();
        Transaction trans = session.beginTransaction();
        session.save(transportation);
        trans.commit();
        session.close();
        System.out.println("Data saved successfully: " + transportation);
    }
}
