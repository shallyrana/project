package com.tanisha.restaurantinventory;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

@Configuration
@EnableAspectJAutoProxy(proxyTargetClass = true)
@ComponentScan("com.tanisha.restaurantinventory")
public class RestaurantInventoryConfig {
    
    @Bean("inventoryItemDAOBean")
    public InventoryItemDAO getInventoryItemDAO() {
        return new InventoryItemDAO();
    }
    
    @Bean("supplierDAOBean")
    public SupplierDAO getSupplierDAO() {
        return new SupplierDAO();
    }
    
    @Bean("transportationDAOBean")
    public TransportationDAO getTransportationDAO() {
        return new TransportationDAO();
    }
    
    @Bean("warehouseDAOBean")
    public WarehouseDAO getWarehouseDAO() {
        return new WarehouseDAO();
    }
}