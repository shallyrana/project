package com.tanisha.restaurantinventory;

import jakarta.persistence.*;

@Entity
@Table(name = "transportation")
public class Transportation {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private int id;

    @Column(name = "supplier_id")
    private int supplierId;

    @Column(name = "vehicle_type")
    private String vehicleType;

    @Column(name = "route")
    private String route;

    @Column(name = "driver_contact")
    private String driverContact;

    @Column(name = "amount_per_trip")
    private double amountPerTrip;
    
    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "supplier_id", insertable = false, updatable = false)
    private Supplier supplier;


    // Constructors
    public Transportation() {
    }

    public Transportation(int supplierId, String vehicleType, String route, String driverContact, double amountPerTrip) {
        this.supplierId = supplierId;
        this.vehicleType = vehicleType;
        this.route = route;
        this.driverContact = driverContact;
        this.amountPerTrip = amountPerTrip;
    }

    // Getters and setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getSupplierId() {
        return supplierId;
    }

    public void setSupplierId(int supplierId) {
        this.supplierId = supplierId;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getRoute() {
        return route;
    }

    public void setRoute(String route) {
        this.route = route;
    }

    public String getDriverContact() {
        return driverContact;
    }

    public void setDriverContact(String driverContact) {
        this.driverContact = driverContact;
    }

    public double getAmountPerTrip() {
        return amountPerTrip;
    }

    public void setAmountPerTrip(double amountPerTrip) {
        this.amountPerTrip = amountPerTrip;
    }
}
