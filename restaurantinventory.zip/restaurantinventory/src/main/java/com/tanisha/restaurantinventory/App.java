package com.tanisha.restaurantinventory;

import java.util.Date;

public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");

        // Saving an Inventory Item
        InventoryItemDAO inventoryItemDAO = new InventoryItemDAO();
        InventoryItem inventoryItem = new InventoryItem("Apple", 100, new Date(), 2.5f);
        inventoryItemDAO.save(inventoryItem);
        inventoryItemDAO.closeSessionFactory();
        
        // Saving a Supplier
        SupplierDAO supplierDAO = new SupplierDAO();
        Supplier supplier = new Supplier("SupplierName", "1234567890", "VehicleType", "ItemsDelivering");
        supplierDAO.save(supplier);
        supplierDAO.closeSessionFactory();
        
        // Saving a Transportation Item
        TransportationDAO transportationDAO = new TransportationDAO();
        Transportation transportation = new Transportation(1, "Truck", "Route 66", "123-456-7890", 1000.0);
        transportationDAO.save(transportation);
        transportationDAO.closeSessionFactory();
        
     // Saving a Warehouse Item
        WarehouseDAO warehouseDAO = new WarehouseDAO();
        Warehouse warehouse = new Warehouse("Warehouse A", 500, "123 Main St", "987-654-3210", 250);
        warehouseDAO.save(warehouse);
        warehouseDAO.closeSessionFactory();
    }
}
