package com.tanisha.restaurantinventory;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class LoggingAspect {

	 // 1. Add Pointcut Declaration
	
    @Pointcut("execution(* com.tanisha.restaurantinventory.*DAO.*(..))")
    private void forDaoPackage() {}

    // Pointcut expression for getter methods
    @Pointcut("execution(* com.tanisha.restaurantinventory.*.get*(..))")
    private void getter() {}

    // Pointcut expression for setter methods
    @Pointcut("execution(* com.tanisha.restaurantinventory.*.set*(..))")
    private void setter() {}

    // Combined pointcut: include package... exclude getter/setter
    @Pointcut("forDaoPackage() && !(getter() || setter())")
    private void forDaoPackageNotGetterSetter() {}

    // 2. Apply Pointcut declaration to advice
    @Before("forDaoPackageNotGetterSetter()")
    public void beforeAddAccount() {
        System.out.println("=====>> Executing @Before advice on any method in the DAO package (excluding getters and setters)");
    }

    // Apply the same pointcut declaration to another advice
    @Before("forDaoPackage()")
    public void beforeAPIAnalytics() {
        System.out.println("=====>> Performing API Analytics");
    }
}
