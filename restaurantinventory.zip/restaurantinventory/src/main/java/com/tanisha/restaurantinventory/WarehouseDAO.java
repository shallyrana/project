package com.tanisha.restaurantinventory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class WarehouseDAO {

    private SessionFactory sessionFactory;

    public WarehouseDAO() {
        this.sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    public void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }

    public void save(Warehouse warehouse) {
        Session session = sessionFactory.openSession();
        Transaction trans = session.beginTransaction();
        session.save(warehouse);
        trans.commit();
        session.close();
        System.out.println("Data saved successfully: " + warehouse);
    }
}

