package com.tanisha.restaurantinventory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class SupplierDAO {

    private SessionFactory sessionFactory;

    public SupplierDAO() {
        this.sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    public void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }

    public void save(Supplier supplier) {
        Session session = sessionFactory.openSession();
        Transaction trans = session.beginTransaction();
        session.save(supplier);
        trans.commit();
        session.close();
        System.out.println("Data saved successfully: " + supplier);
    }
}
