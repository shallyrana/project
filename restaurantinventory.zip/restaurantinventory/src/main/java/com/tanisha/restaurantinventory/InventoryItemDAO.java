package com.tanisha.restaurantinventory;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

public class InventoryItemDAO {

    private SessionFactory sessionFactory;

    public InventoryItemDAO() {
        this.sessionFactory = new Configuration().configure("hibernate.cfg.xml").buildSessionFactory();
    }

    public void closeSessionFactory() {
        if (sessionFactory != null && !sessionFactory.isClosed()) {
            sessionFactory.close();
        }
    }

    public void save(InventoryItem inventoryItem) {
        Session session = sessionFactory.openSession();
        Transaction trans = session.beginTransaction();
        session.save(inventoryItem);
        trans.commit();
        session.close();
        System.out.println("Data saved successfully: " + inventoryItem);
    }

    public InventoryItem getInventoryItemById(int id) {
        Session session = sessionFactory.openSession();
        InventoryItem item = session.get(InventoryItem.class, id);
        session.close();
        return item;
    }
}
