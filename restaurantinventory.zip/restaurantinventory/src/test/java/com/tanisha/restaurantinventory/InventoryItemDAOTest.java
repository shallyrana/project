package com.tanisha.restaurantinventory;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

public class InventoryItemDAOTest {

    @Test
    public void testGetInventoryItemById() {
        // Create an instance of InventoryItemDAO
        InventoryItemDAO inventoryItemDAO = new InventoryItemDAO();

        // Call the method to be tested
        InventoryItem item = inventoryItemDAO.getInventoryItemById(1);

        // Assert that the returned item is not null
        assertNotNull(item);

        // Assert other properties of the returned item if applicable
        assertEquals(1, item.getId());
        assertEquals("Item Name", item.getFoodName());
        // Add more assertions as needed
    }

	private void assertNotNull(InventoryItem item) {
		// TODO Auto-generated method stub
		
	}
}

